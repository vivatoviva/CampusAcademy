;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-account" viewBox="0 0 1025 1024">' +
    '' +
    '<path d="M944.02227 920.429904C886.277185 761.905835 771.601005 646.734094 635.487737 602.525797c27.283472-13.498904 52.477195-31.503928 74.632025-53.658758 53.344425-53.344425 82.721743-124.267938 82.721743-199.707809 0-75.439871-29.377318-146.364407-82.721743-199.707809s-124.268962-82.721743-199.708833-82.721743-146.364407 29.377318-199.707809 82.721743S227.981378 273.719359 227.981378 349.158206c0 75.439871 29.377318 146.364407 82.721743 199.707809 22.186571 22.186571 47.422273 40.211048 74.75182 53.71712-136.034428 44.252324-250.634841 159.392324-308.354328 317.846769-2.745037 7.533748-1.640264 15.933703 2.958005 22.502952 4.598269 6.568224 12.112563 10.48049 20.131633 10.48049l820.743405 0c8.018046 0 15.53234-3.912266 20.130609-10.48049C945.662534 936.363607 946.766282 927.964676 944.02227 920.429904zM277.127874 349.158206c0-62.311613 24.266082-120.89526 68.326939-164.956117 44.060857-44.061881 102.644504-68.326939 164.956117-68.326939s120.89526 24.266082 164.956117 68.326939c44.061881 44.060857 68.326939 102.644504 68.326939 164.956117 0 62.312637-24.265058 120.89526-68.326939 164.956117-44.060857 44.061881-102.64348 68.326939-164.956117 68.326939-62.311613 0-120.89526-24.265058-164.956117-68.326939C301.393956 470.053466 277.127874 411.470843 277.127874 349.158206zM136.475723 904.26685c33.140096-75.787992 81.511511-140.31734 141.237813-188.041659 69.148095-55.252948 149.665413-84.457229 232.847905-84.457229 83.181468 0 163.698786 29.204281 232.846881 84.457229 59.727327 47.724319 108.098741 112.254691 141.238837 188.041659L136.475723 904.26685z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)